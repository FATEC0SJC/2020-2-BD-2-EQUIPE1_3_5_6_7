Guia de usuário:

!Atenção esse software ainda está em desenvolvimento

!Primeiro exceute o "PrepararBanco" para a criação do banco de dados e suas tabelas
	Primeiro coloque o User e a Senha do seu banco de dados. Espere alguns segundos, 
	uma mensagem confirmando a criação deve aparecer;

	Em seguida crie os logins que quiser, eles serão utilizados para acessar o programa 
	e registrar o digitador;

	Pronto! Agora você só irá utilizar "CadastroDeContas".

**********************************************************************************************

Conectar ao BD:

	Coloque o User e Senha do seu banco de dados para o programa conectar.

Login:

	Utilize "admin" e "password" ou um dos logins que você criou em "PrepararBanco".

Tela Inicial:

	Clique no botão "Água" ou aperte ctrl + a para iniciar a tela de digitação de contas de água;

	Clique no botão "Luz" ou aperte ctrl + s para iniciar a tela de digitação de contas de luz;

	Clique no botão "Relatório" para acesar a tela onde poderá criar um arquivo csv de uma conta específica.


Tela Água:

	Primeiro digite o RGI, caso o cliente com esse RGI ainda não esteja no sistema você 
	não poderá prosseguir;

	Insira os dados em seus respectivos campos, utilizando ponto (".") no lugar de virgula!;

	Para salvar no banco de dados clique em "Salvar" ou aperte ctrl + s;

	Para salvar os dados digitados em formato "txt" clique no botão "Criar arquivo";

    	Para procurar por uma conta já cadastrada digite o RGI e clique em "Procurar" ou aperte ctrl + d;

    	Para limpar os campos de digitação clique em "Limpar" ou aperte ctrl + f;


Tela Luz:

	Primeiro digite a Instalação, caso o cliente com essa Instalação ainda não esteja no sistema 
	você não poderá prosseguir;

	Insira os dados em seus respectivos campos, utilizando ponto (".") no lugar de virgula!;

    	Para salvar no banco de dados clique em "Salvar" ou aperte ctrl + s;

    	Para salvar os dados digitados em formato "txt" clique no botão "Criar arquivo";

    	Para procurar por uma conta já cadastrada digite a instalação e clique em "Procurar" ou aperte ctrl + d;

    	Para limpar os campos de digitação clique em "Limpar" ou aperte ctrl + f.

	==> Como editar uma conta já cadastrada:
    
    		Em caso de erro de digitação ou contas com dados errados, basta procurar pelo cadastro 
		com o botão "Procurar", corrigir o(s) campo(s) errados e clicar em "Salvar";


Tela Relatório:

	Primeiro digite o nome do cliente. A barrá irá sugerir e autocompletar de acordo com os clientes 
	já cadastrados;

	Selecione o mês da conta (mês de referência) e se a conta é de água ou luz;

	Clique em "Ver" para ver alguns dados daquela conta. Caso a conta exista todos os campos da 
	tela serão preenchidos, caso a conta não exista apenas o RGI/Instalação e Cidade serão mostrados;

	Você pode clicar em "Criar CSV" parar criar um arquivo do excel com mais detalhes sobre a conta e cliente.

		==> Lembrando que no excel é preciso ir na aba "Dados", "Texto para Colunas", 
		"Delimitado" avançar, deixar "Vírgula" marcado e avançar, concluir.
